-- Library Management System Database Schema (cleaned & consolidated)

CREATE DATABASE IF NOT EXISTS abcoad_library;
USE abcoad_library;

-- ============================================================
-- Admins Table
-- ============================================================
CREATE TABLE IF NOT EXISTS admins (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Students Table
-- ============================================================
CREATE TABLE IF NOT EXISTS students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id VARCHAR(20) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    profile_picture VARCHAR(255) DEFAULT 'default.jpg',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Categories Table
-- ============================================================
CREATE TABLE IF NOT EXISTS categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Authors Table
-- ============================================================
CREATE TABLE IF NOT EXISTS authors (
    id INT PRIMARY KEY AUTO_INCREMENT,
    author_name VARCHAR(100) NOT NULL,
    bio TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Books Table
-- ============================================================
CREATE TABLE IF NOT EXISTS books (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    isbn VARCHAR(20) UNIQUE NOT NULL,
    author_id INT NOT NULL,
    category_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    available_quantity INT NOT NULL DEFAULT 1,
    publication_year YEAR,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_author_id (author_id),
    KEY idx_category_id (category_id),
    FOREIGN KEY (author_id) REFERENCES authors(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Book Requests Table (single canonical version)
-- A student requests a book; admin approves/rejects it.
-- ============================================================
CREATE TABLE IF NOT EXISTS book_requests (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    book_id INT NOT NULL,
    request_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending','approved','rejected','cancelled') DEFAULT 'pending',
    admin_response TEXT DEFAULT NULL,
    response_date DATETIME DEFAULT NULL,
    notes TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_student_id (student_id),
    KEY idx_book_id (book_id),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Issued Books Table
-- Linked back to the originating request so the full
-- request -> issue -> return lifecycle can be traced.
-- ============================================================
CREATE TABLE IF NOT EXISTS issued_books (
    id INT PRIMARY KEY AUTO_INCREMENT,
    request_id INT DEFAULT NULL,
    book_id INT NOT NULL,
    student_id INT NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE NULL,
    status ENUM('issued', 'returned') DEFAULT 'issued',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_book_id (book_id),
    KEY idx_student_id (student_id),
    FOREIGN KEY (request_id) REFERENCES book_requests(id) ON DELETE SET NULL,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Password Reset Table (single consolidated table,
-- replaces both password_reset and forgot_password)
-- ============================================================
CREATE TABLE IF NOT EXISTS password_reset (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_type ENUM('admin', 'student') NOT NULL,
    email VARCHAR(100) NOT NULL,
    token VARCHAR(100) NOT NULL UNIQUE,
    used TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    KEY idx_email (email),
    KEY idx_token (token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Default Admin
-- Default password: password
-- ============================================================
INSERT INTO admins (username, email, password, full_name)
VALUES ('admin', 'admin@library.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Admin');

-- ============================================================
-- Sample Categories
-- ============================================================
INSERT INTO categories (category_name, description) VALUES
('Fiction', 'Fictional literature and novels'),
('Non-Fiction', 'Educational and factual books'),
('Science', 'Scientific publications and research'),
('Technology', 'Computer science and technology books'),
('History', 'Historical documents and books');

-- ============================================================
-- Sample Authors
-- ============================================================
INSERT INTO authors (author_name, bio) VALUES
('J.K. Rowling', 'British author, best known for Harry Potter series'),
('Stephen King', 'American author of horror and suspense novels'),
('Isaac Asimov', 'Science fiction author and biochemistry professor'),
('Malcolm Gladwell', 'Canadian journalist and author');

-- ============================================================
-- Sample Books
-- ============================================================
INSERT INTO books (title, isbn, author_id, category_id, quantity, available_quantity, publication_year, description) VALUES
('Harry Potter and the Philosopher\'s Stone', '978-0747532699', 1, 1, 5, 5, 1997, 'First book in the Harry Potter series'),
('The Shining', '978-0307743657', 2, 1, 3, 3, 1977, 'Horror novel by Stephen King'),
('Foundation', '978-0553293357', 3, 3, 4, 4, 1951, 'Science fiction novel'),
('Outliers', '978-0316017923', 4, 2, 6, 6, 2008, 'Book about success and opportunity');






ALTER TABLE book_requests
    ADD COLUMN request_type ENUM('borrow','return') NOT NULL DEFAULT 'borrow' AFTER book_id,
    ADD COLUMN issued_book_id INT DEFAULT NULL AFTER request_type;

ALTER TABLE book_requests
    ADD CONSTRAINT fk_book_requests_issued_book
    FOREIGN KEY (issued_book_id) REFERENCES issued_books(id) ON DELETE CASCADE;

ALTER TABLE book_requests
    ADD KEY idx_issued_book_id (issued_book_id);
