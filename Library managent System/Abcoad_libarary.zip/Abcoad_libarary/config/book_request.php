<?php
require_once 'config.php';

// Check if student is logged in
if (!isStudent()) {
    header('Location: student_login.php');
    exit();
}

$student_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Handle book request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['request_book'])) {
    $book_id = intval($_POST['book_id']);
    $notes = sanitize($_POST['notes']);
    
    // Check if student already requested this book
    $check_query = "SELECT * FROM book_requests WHERE student_id = ? AND book_id = ? AND status != 'rejected' AND status != 'cancelled'";
    $check_stmt = mysqli_prepare($conn, $check_query);
    mysqli_stmt_bind_param($check_stmt, "si", $student_id, $book_id);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);
    
    if (mysqli_num_rows($check_result) > 0) {
        $error = "You have already requested this book!";
    } else {
        // Insert request
        $request_query = "INSERT INTO book_requests (student_id, book_id, notes) VALUES (?, ?, ?)";
        $request_stmt = mysqli_prepare($conn, $request_query);
        mysqli_stmt_bind_param($request_stmt, "sis", $student_id, $book_id, $notes);
        
        if (mysqli_stmt_execute($request_stmt)) {
            $success = "✓ Book request submitted successfully! Admin will review it soon.";
        } else {
            $error = "Error submitting request!";
        }
        
        mysqli_stmt_close($request_stmt);
    }
    
    mysqli_stmt_close($check_stmt);
}

// Get books not currently borrowed by student and available
$query = "SELECT b.*, 
          (SELECT name FROM authors WHERE id = b.author_id) as author_name,
          (SELECT name FROM categories WHERE id = b.category_id) as category_name,
          (SELECT COUNT(*) FROM issued_books WHERE student_id = ? AND book_id = b.id AND return_date IS NULL) as is_borrowed,
          (SELECT COUNT(*) FROM book_requests WHERE student_id = ? AND book_id = b.id AND status = 'pending') as has_pending_request
          FROM books b 
          WHERE b.available > 0
          ORDER BY b.title ASC";

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "ss", $student_id, $student_id);
mysqli_stmt_execute($stmt);
$books_result = mysqli_stmt_get_result($stmt);

// Get student's requests
$my_requests_query = "SELECT br.*, b.title, 
                      (SELECT name FROM authors WHERE id = b.author_id) as author_name
                      FROM book_requests br
                      JOIN books b ON br.book_id = b.id
                      WHERE br.student_id = ?
                      ORDER BY br.request_date DESC";

$my_requests_stmt = mysqli_prepare($conn, $my_requests_query);
mysqli_stmt_bind_param($my_requests_stmt, "s", $student_id);
mysqli_stmt_execute($my_requests_stmt);
$my_requests_result = mysqli_stmt_get_result($my_requests_stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Books</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: white;
            text-decoration: none;
            font-weight: 600;
            padding: 10px 20px;
            background: rgba(255,255,255,0.2);
            border-radius: 8px;
        }

        .header {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .header h1 {
            color: #333;
            margin-bottom: 10px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }

        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid #ef4444;
        }

        .section-title {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin: 20px 0 15px 0;
            border-left: 5px solid #667eea;
            color: #333;
            font-size: 1.3em;
            font-weight: 700;
        }

        .books-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .book-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
            display: flex;
            flex-direction: column;
        }

        .book-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }

        .book-title {
            font-size: 1.1em;
            font-weight: 700;
            color: #333;
            margin-bottom: 8px;
        }

        .book-author {
            color: #6b7280;
            margin-bottom: 10px;
            font-size: 0.9em;
        }

        .book-info {
            color: #9ca3af;
            font-size: 0.85em;
            margin-bottom: 10px;
        }

        .availability-badge {
            display: inline-block;
            background: #d1fae5;
            color: #065f46;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .request-form {
            margin-top: auto;
            padding-top: 15px;
            border-top: 1px solid #e5e7eb;
        }

        .form-group {
            margin-bottom: 10px;
        }

        .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            font-size: 0.85em;
            font-family: inherit;
            resize: vertical;
            min-height: 60px;
            margin-bottom: 10px;
        }

        .btn {
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            transition: transform 0.2s;
        }

        .btn-request {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn:hover {
            transform: scale(1.02);
        }

        .requests-table {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }

        td {
            padding: 12px 15px;
            border-bottom: 1px solid #e5e7eb;
        }

        tbody tr:hover {
            background: #f9fafb;
        }

        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 600;
            display: inline-block;
        }

        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }

        .status-approved {
            background: #d1fae5;
            color: #065f46;
        }

        .status-rejected {
            background: #fee2e2;
            color: #991b1b;
        }

        .no-data {
            text-align: center;
            padding: 40px 20px;
            color: #6b7280;
        }

        @media (max-width: 768px) {
            .books-grid {
                grid-template-columns: 1fr;
            }

            table {
                font-size: 0.9em;
            }

            th, td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="student_dashboard.php" class="back-link">← Back to Dashboard</a>

        <div class="header">
            <h1>📚 Request Books</h1>
            <p>Request books that are currently unavailable. Admins will review your request.</p>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success">✓ <?php echo $success; ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error">✕ <?php echo $error; ?></div>
        <?php endif; ?>

        <div class="section-title">📖 Available Books to Request</div>

        <div class="books-grid">
            <?php while ($book = mysqli_fetch_assoc($books_result)): ?>
                <?php if (!$book['is_borrowed']): ?>
                    <div class="book-card">
                        <div class="book-title"><?php echo htmlspecialchars($book['title']); ?></div>
                        <div class="book-author">by <?php echo htmlspecialchars($book['author_name']); ?></div>
                        <div class="book-info">Category: <?php echo htmlspecialchars($book['category_name']); ?></div>
                        <div class="availability-badge">
                            ✓ <?php echo $book['available']; ?> Available
                        </div>

                        <form method="POST" action="" class="request-form">
                            <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                            <div class="form-group">
                                <textarea name="notes" placeholder="Why do you need this book? (Optional)"></textarea>
                            </div>
                            <button type="submit" name="request_book" class="btn btn-request" <?php echo ($book['has_pending_request'] > 0) ? 'disabled' : ''; ?>>
                                <?php echo ($book['has_pending_request'] > 0) ? '⏳ Request Pending' : '📤 Request This Book'; ?>
                            </button>
                        </form>
                    </div>
                <?php endif; ?>
            <?php endwhile; ?>
        </div>

        <div class="section-title">📋 My Book Requests</div>

        <div class="requests-table">
            <?php if (mysqli_num_rows($my_requests_result) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Book Title</th>
                            <th>Request Date</th>
                            <th>Status</th>
                            <th>Admin Response</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($request = mysqli_fetch_assoc($my_requests_result)): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($request['title']); ?></strong></td>
                                <td><?php echo formatDate($request['request_date']); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo strtolower($request['status']); ?>">
                                        <?php echo ucfirst($request['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo $request['admin_response'] ? htmlspecialchars($request['admin_response']) : '-'; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-data">
                    <p>You haven't made any book requests yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

<?php mysqli_close($conn); ?>