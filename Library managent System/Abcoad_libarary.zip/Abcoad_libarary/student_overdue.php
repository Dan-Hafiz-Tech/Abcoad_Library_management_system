<?php
require_once 'config.php';

// Check if student is logged in
if (!isStudent()) {
    header('Location: student_login.php');
    exit();
}

$student_id = $_SESSION['user_id'];

// Get student's overdue books
$query = "SELECT ib.*, b.title, b.isbn, 
          COALESCE(a.name, a.author_name, a.full_name) as author_name,
          DATEDIFF(CURDATE(), ib.due_date) as days_overdue,
          (DATEDIFF(CURDATE(), ib.due_date) * 10) as fine_amount
          FROM issued_books ib
          JOIN books b ON ib.book_id = b.id
          JOIN authors a ON b.author_id = a.id
          WHERE ib.student_id = ? 
          AND ib.return_date IS NULL 
          AND ib.due_date < CURDATE()
          ORDER BY ib.due_date ASC";

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "s", $student_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Calculate total fines
$total_fine = 0;
$books_data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $total_fine += $row['fine_amount'];
    $books_data[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Overdue Books</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: white;
            text-decoration: none;
            font-weight: 600;
            padding: 10px 20px;
            background: rgba(255,255,255,0.2);
            border-radius: 8px;
        }

        .header {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .header h1 {
            color: #ef4444;
            margin-bottom: 10px;
        }

        .alert-danger {
            background: #fee2e2;
            border-left: 4px solid #ef4444;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            color: #991b1b;
        }

        .alert-danger h3 {
            margin-bottom: 10px;
        }

        .total-fine {
            font-size: 1.5em;
            font-weight: 700;
            color: #ef4444;
            margin-top: 10px;
        }

        .books-list {
            display: grid;
            gap: 15px;
        }

        .book-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            border-left: 5px solid #ef4444;
        }

        .book-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 10px;
        }

        .book-title {
            font-size: 1.2em;
            font-weight: 700;
            color: #111827;
        }

        .overdue-badge {
            background: #fee2e2;
            color: #991b1b;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 0.9em;
        }

        .book-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #e5e7eb;
        }

        .detail-item {
            display: flex;
            flex-direction: column;
        }

        .detail-label {
            color: #6b7280;
            font-size: 0.85em;
            margin-bottom: 3px;
        }

        .detail-value {
            color: #111827;
            font-weight: 600;
        }

        .fine-display {
            background: #fef2f2;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            margin-top: 15px;
        }

        .fine-label {
            color: #6b7280;
            font-size: 0.9em;
            margin-bottom: 5px;
        }

        .fine-amount {
            color: #ef4444;
            font-size: 1.8em;
            font-weight: 700;
        }

        .no-overdue {
            background: white;
            padding: 60px 20px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .no-overdue h2 {
            color: #10b981;
            margin-bottom: 10px;
        }

        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 25px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
        }

        @media (max-width: 768px) {
            .book-header {
                flex-direction: column;
            }

            .book-details {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="student_dashboard.php" class="back-link">← Back to Dashboard</a>

        <div class="header">
            <h1>⚠️ My Overdue Books</h1>
            <p>Please return these books as soon as possible to avoid additional fines</p>
        </div>

        <?php if (count($books_data) > 0): ?>
            <div class="alert-danger">
                <h3>⚠️ Action Required!</h3>
                <p>You have <?php echo count($books_data); ?> overdue book(s). Please return them to the library immediately.</p>
                <div class="total-fine">
                    Total Fine: ₦<?php echo number_format($total_fine, 2); ?>
                </div>
                <small>Fine rate: ₦10 per day per book</small>
            </div>

            <div class="books-list">
                <?php foreach ($books_data as $book): ?>
                    <div class="book-card">
                        <div class="book-header">
                            <div>
                                <div class="book-title"><?php echo htmlspecialchars($book['title']); ?></div>
                                <div style="color: #6b7280; margin-top: 5px;">
                                    by <?php echo htmlspecialchars($book['author_name']); ?>
                                </div>
                            </div>
                            <div class="overdue-badge">
                                <?php echo $book['days_overdue']; ?> days overdue
                            </div>
                        </div>

                        <div class="book-details">
                            <div class="detail-item">
                                <span class="detail-label">ISBN</span>
                                <span class="detail-value"><?php echo htmlspecialchars($book['isbn']); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Issue Date</span>
                                <span class="detail-value"><?php echo formatDate($book['issue_date']); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Due Date</span>
                                <span class="detail-value"><?php echo formatDate($book['due_date']); ?></span>
                            </div>
                        </div>

                        <div class="fine-display">
                            <div class="fine-label">Fine Amount</div>
                            <div class="fine-amount">₦<?php echo number_format($book['fine_amount'], 2); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="no-overdue">
                <h2>✅ No Overdue Books!</h2>
                <p>Great job! You have no overdue books.</p>
                <a href="my_borrowed_books.php" class="btn">View My Borrowed Books</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

<?php mysqli_close($conn); ?>