<?php
require_once 'config.php';

// Check if admin is logged in
if (!isAdmin()) {
    header('Location: admin_login.php');
    exit();
}

// Get overdue books - FIXED QUERY
$query = "SELECT ib.*, b.title, b.isbn, b.author_id,
          s.name as student_name, s.student_id, s.email as student_email, s.phone as student_phone,
          DATEDIFF(CURDATE(), ib.due_date) as days_overdue,
          (DATEDIFF(CURDATE(), ib.due_date) * 10) as fine_amount
          FROM issued_books ib
          JOIN books b ON ib.book_id = b.id
          JOIN students s ON ib.student_id = s.id
          WHERE ib.return_date IS NULL 
          AND ib.due_date < CURDATE()
          ORDER BY ib.due_date ASC";

$result = mysqli_query($conn, $query);

// Fetch data and add author names
$overdue_data = [];
while ($row = mysqli_fetch_assoc($result)) {
    // Get author name separately
    $author_query = "SELECT * FROM authors WHERE id = ?";
    $author_stmt = mysqli_prepare($conn, $author_query);
    mysqli_stmt_bind_param($author_stmt, "i", $row['author_id']);
    mysqli_stmt_execute($author_stmt);
    $author_result = mysqli_stmt_get_result($author_stmt);
    $author = mysqli_fetch_assoc($author_result);
    
    // Use whatever column exists
    $row['author_name'] = $author['name'] ?? $author['author_name'] ?? $author['full_name'] ?? 'Unknown';
    
    $overdue_data[] = $row;
    mysqli_stmt_close($author_stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Overdue Books - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: white;
            text-decoration: none;
            font-weight: 600;
            padding: 10px 20px;
            background: rgba(255,255,255,0.2);
            border-radius: 8px;
            transition: background 0.3s;
        }

        .back-link:hover {
            background: rgba(255,255,255,0.3);
        }

        .header {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .header h1 {
            color: #ef4444;
            margin-bottom: 10px;
        }

        .header p {
            color: #6b7280;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            text-align: center;
        }

        .stat-number {
            font-size: 2.5em;
            font-weight: 700;
            color: #ef4444;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #6b7280;
            font-size: 0.9em;
            font-weight: 600;
        }

        .alert-warning {
            background: #fef3c7;
            border-left: 4px solid #f59e0b;
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            color: #92400e;
            font-weight: 500;
        }

        .table-container {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
        }

        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 0.9em;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #e5e7eb;
        }

        tbody tr:hover {
            background: #fef2f2;
        }

        tbody tr:last-child td {
            border-bottom: none;
        }

        .overdue-badge {
            background: #fee2e2;
            color: #991b1b;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 700;
        }

        .fine-amount {
            color: #ef4444;
            font-weight: 700;
            font-size: 1.1em;
        }

        .contact-info {
            font-size: 0.85em;
            color: #6b7280;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            justify-content: center;
        }

        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: transform 0.2s;
        }

        .btn:hover {
            transform: scale(1.02);
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-danger {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
        }

        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }

        .no-data h2 {
            color: #10b981;
            margin-bottom: 10px;
        }

        @media (max-width: 768px) {
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 900px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="admin_dashboard.php" class="back-link">← Back to Dashboard</a>

        <div class="header">
            <h1>⚠️ Overdue Books</h1>
            <p>Books that are past their due date and need immediate attention</p>
        </div>

        <?php if ($fines_stats['total_overdue'] > 0): ?>
            <div class="alert-warning">
                ⚠️ <strong>Alert:</strong> There are <?php echo $fines_stats['total_overdue']; ?> overdue books requiring action. 
                Total pending fines: ₦<?php echo number_format($fines_stats['total_fines'], 2); ?>
            </div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo $fines_stats['total_overdue'] ?: 0; ?></div>
                <div class="stat-label">Overdue Books</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $fines_stats['total_days_overdue'] ?: 0; ?></div>
                <div class="stat-label">Total Days Overdue</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">₦<?php echo number_format($fines_stats['total_fines'] ?: 0, 2); ?></div>
                <div class="stat-label">Total Fines (₦10/day)</div>
            </div>
        </div>

        <div class="table-container">
            <?php if (mysqli_num_rows($result) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Issue ID</th>
                            <th>Book Details</th>
                            <th>Student Details</th>
                            <th>Issue Date</th>
                            <th>Due Date</th>
                            <th>Days Overdue</th>
                            <th>Fine (₦10/day)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><strong>#<?php echo $row['id']; ?></strong></td>
                                <td>
                                    <strong style="color: #111827;"><?php echo htmlspecialchars($row['title']); ?></strong><br>
                                    <span class="contact-info">by <?php echo htmlspecialchars($row['author_name']); ?></span><br>
                                    <span class="contact-info">ISBN: <?php echo htmlspecialchars($row['isbn']); ?></span>
                                </td>
                                <td>
                                    <strong style="color: #111827;"><?php echo htmlspecialchars($row['student_name']); ?></strong><br>
                                    <span class="contact-info"><?php echo htmlspecialchars($row['student_id']); ?></span><br>
                                    <span class="contact-info">📧 <?php echo htmlspecialchars($row['student_email']); ?></span><br>
                                    <?php if ($row['student_phone']): ?>
                                        <span class="contact-info">📱 <?php echo htmlspecialchars($row['student_phone']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo formatDate($row['issue_date']); ?></td>
                                <td><?php echo formatDate($row['due_date']); ?></td>
                                <td>
                                    <span class="overdue-badge">
                                        <?php echo $row['days_overdue']; ?> days
                                    </span>
                                </td>
                                <td>
                                    <span class="fine-amount">
                                        ₦<?php echo number_format($row['fine_amount'], 2); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <div class="action-buttons">
                    <a href="print_overdue.php" class="btn btn-primary" target="_blank">🖨️ Print Report</a>
                    <a href="send_reminders.php" class="btn btn-danger">📧 Send Reminders</a>
                </div>
            <?php else: ?>
                <div class="no-data">
                    <h2>✅ Great News!</h2>
                    <p>No overdue books at the moment. All books are returned on time!</p>
                    <a href="recent_issues.php" class="btn btn-primary" style="margin-top: 20px;">View All Issues</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

<?php mysqli_close($conn); ?>