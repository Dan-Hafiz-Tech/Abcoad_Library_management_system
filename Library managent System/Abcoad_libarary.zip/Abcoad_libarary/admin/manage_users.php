<?php
// admin/manage_users.php
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: admin_login.php');
    exit();
}

$error = '';
$success = '';

// ------------------------------------------------------------
// Handle actions: add_student, add_admin, edit_student, edit_admin,
// delete_student, delete_admin
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    // ---- Add Student ----
    if ($action === 'add_student') {
        $student_id = sanitize($_POST['student_id']);
        $full_name  = sanitize($_POST['full_name']);
        $email      = sanitize($_POST['email']);
        $password   = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $phone      = sanitize($_POST['phone']);

        $stmt = mysqli_prepare($conn, "INSERT INTO students (student_id, full_name, email, password, phone) VALUES (?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sssss", $student_id, $full_name, $email, $password, $phone);
        if (mysqli_stmt_execute($stmt)) {
            $success = "Student added successfully.";
        } else {
            $error = "Error adding student: " . mysqli_error($conn);
        }
    }

    // ---- Add Admin ----
    if ($action === 'add_admin') {
        $username  = sanitize($_POST['username']);
        $full_name = sanitize($_POST['full_name']);
        $email     = sanitize($_POST['email']);
        $password  = password_hash($_POST['password'], PASSWORD_DEFAULT);

        $stmt = mysqli_prepare($conn, "INSERT INTO admins (username, full_name, email, password) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssss", $username, $full_name, $email, $password);
        if (mysqli_stmt_execute($stmt)) {
            $success = "Admin added successfully.";
        } else {
            $error = "Error adding admin: " . mysqli_error($conn);
        }
    }

    // ---- Edit Student ----
    if ($action === 'edit_student') {
        $id        = (int)$_POST['id'];
        $full_name = sanitize($_POST['full_name']);
        $email     = sanitize($_POST['email']);
        $phone     = sanitize($_POST['phone']);

        if (!empty($_POST['password'])) {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($conn, "UPDATE students SET full_name=?, email=?, phone=?, password=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, "ssssi", $full_name, $email, $phone, $password, $id);
        } else {
            $stmt = mysqli_prepare($conn, "UPDATE students SET full_name=?, email=?, phone=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, "sssi", $full_name, $email, $phone, $id);
        }

        if (mysqli_stmt_execute($stmt)) {
            $success = "Student updated successfully.";
        } else {
            $error = "Error updating student: " . mysqli_error($conn);
        }
    }

    // ---- Edit Admin ----
    if ($action === 'edit_admin') {
        $id        = (int)$_POST['id'];
        $full_name = sanitize($_POST['full_name']);
        $email     = sanitize($_POST['email']);

        if (!empty($_POST['password'])) {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($conn, "UPDATE admins SET full_name=?, email=?, password=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, "sssi", $full_name, $email, $password, $id);
        } else {
            $stmt = mysqli_prepare($conn, "UPDATE admins SET full_name=?, email=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, "ssi", $full_name, $email, $id);
        }

        if (mysqli_stmt_execute($stmt)) {
            $success = "Admin updated successfully.";
        } else {
            $error = "Error updating admin: " . mysqli_error($conn);
        }
    }

    // ---- Delete Student ----
    if ($action === 'delete_student') {
        $id = (int)$_POST['id'];
        $stmt = mysqli_prepare($conn, "DELETE FROM students WHERE id=?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        if (mysqli_stmt_execute($stmt)) {
            $success = "Student deleted.";
        } else {
            $error = "Error deleting student: " . mysqli_error($conn);
        }
    }

    // ---- Delete Admin ----
    if ($action === 'delete_admin') {
        $id = (int)$_POST['id'];

        if ($id === (int)$_SESSION['user_id']) {
            $error = "You cannot delete your own admin account while logged in.";
        } else {
            $stmt = mysqli_prepare($conn, "DELETE FROM admins WHERE id=?");
            mysqli_stmt_bind_param($stmt, "i", $id);
            if (mysqli_stmt_execute($stmt)) {
                $success = "Admin deleted.";
            } else {
                $error = "Error deleting admin: " . mysqli_error($conn);
            }
        }
    }
}

// ------------------------------------------------------------
// Fetch current lists
// ------------------------------------------------------------
$students = mysqli_query($conn, "SELECT id, student_id, full_name, email, phone, created_at FROM students ORDER BY full_name");
$admins   = mysqli_query($conn, "SELECT id, username, full_name, email, created_at FROM admins ORDER BY full_name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Users</title>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background:#f4f6f8; padding:30px; }
    .container { max-width:1100px; margin:0 auto; }
    h1 { color:#333; margin-bottom:20px; }
    h2 { color:#444; margin:30px 0 15px; }
    .btn { display:inline-block; padding:8px 16px; background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);
           color:#fff; border:none; border-radius:6px; cursor:pointer; text-decoration:none; font-size:0.9em; }
    .btn-danger { background:#e74c3c; }
    .btn-small { padding:5px 10px; font-size:0.8em; margin-right:5px; }
    .card { background:#fff; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.08); padding:20px; margin-bottom:20px; }
    table { width:100%; border-collapse:collapse; margin-top:10px; }
    th, td { text-align:left; padding:10px; border-bottom:1px solid #eee; font-size:0.9em; }
    th { background:#f8f9fa; color:#555; }
    .alert-error { background:#fee; color:#c33; border:1px solid #fcc; padding:12px; border-radius:8px; margin-bottom:20px; }
    .alert-success { background:#e8f8ef; color:#27ae60; border:1px solid #b7ebc6; padding:12px; border-radius:8px; margin-bottom:20px; }
    .form-row { display:flex; flex-wrap:wrap; gap:10px; margin-top:15px; }
    .form-row input, .form-row select { flex:1; min-width:150px; padding:10px; border:2px solid #e1e8ed; border-radius:6px; }
    .top-actions { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; }
    .modal-bg { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.4); z-index:10; }
    .modal-bg.active { display:flex; align-items:center; justify-content:center; }
    .modal { background:#fff; padding:25px; border-radius:10px; width:400px; max-width:90%; }
    .modal h3 { margin-bottom:15px; }
    .modal .form-row input { min-width:100%; margin-bottom:10px; }
    .close-modal { float:right; cursor:pointer; color:#999; }
</style>
</head>
<body>
<div class="container">

    <div class="top-actions">
        <h1>Manage Users</h1>
        <a href="admin_dashboard.php" class="btn">← Back to Dashboard</a>
    </div>

    <?php if ($error): ?><div class="alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert-success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>

    <!-- ================= STUDENTS ================= -->
    <div class="card">
        <div class="top-actions">
            <h2 style="margin:0;">Students</h2>
            <button class="btn" onclick="document.getElementById('addStudentModal').classList.add('active')">+ Add Student</button>
        </div>
        <table>
            <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th>Actions</th></tr></thead>
            <tbody>
            <?php while ($s = mysqli_fetch_assoc($students)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($s['student_id']); ?></td>
                    <td><?php echo htmlspecialchars($s['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($s['email']); ?></td>
                    <td><?php echo htmlspecialchars($s['phone']); ?></td>
                    <td><?php echo htmlspecialchars($s['created_at']); ?></td>
                    <td>
                        <button class="btn btn-small" onclick='openEditStudent(<?php echo json_encode($s); ?>)'>Edit</button>
                        <form method="POST" style="display:inline" onsubmit="return confirm('Delete this student?');">
                            <input type="hidden" name="action" value="delete_student">
                            <input type="hidden" name="id" value="<?php echo $s['id']; ?>">
                            <button type="submit" class="btn btn-small btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- ================= ADMINS ================= -->
    <div class="card">
        <div class="top-actions">
            <h2 style="margin:0;">Admins</h2>
            <button class="btn" onclick="document.getElementById('addAdminModal').classList.add('active')">+ Add Admin</button>
        </div>
        <table>
            <thead><tr><th>Username</th><th>Name</th><th>Email</th><th>Joined</th><th>Actions</th></tr></thead>
            <tbody>
            <?php while ($a = mysqli_fetch_assoc($admins)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($a['username']); ?></td>
                    <td><?php echo htmlspecialchars($a['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($a['email']); ?></td>
                    <td><?php echo htmlspecialchars($a['created_at']); ?></td>
                    <td>
                        <button class="btn btn-small" onclick='openEditAdmin(<?php echo json_encode($a); ?>)'>Edit</button>
                        <?php if ((int)$a['id'] !== (int)$_SESSION['user_id']): ?>
                        <form method="POST" style="display:inline" onsubmit="return confirm('Delete this admin?');">
                            <input type="hidden" name="action" value="delete_admin">
                            <input type="hidden" name="id" value="<?php echo $a['id']; ?>">
                            <button type="submit" class="btn btn-small btn-danger">Delete</button>
                        </form>
                        <?php else: ?>
                            <span style="color:#999; font-size:0.8em;">(you)</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>

</div>

<!-- ================= ADD STUDENT MODAL ================= -->
<div class="modal-bg" id="addStudentModal">
    <div class="modal">
        <span class="close-modal" onclick="document.getElementById('addStudentModal').classList.remove('active')">✕</span>
        <h3>Add Student</h3>
        <form method="POST">
            <input type="hidden" name="action" value="add_student">
            <div class="form-row"><input type="text" name="student_id" placeholder="Student ID" required></div>
            <div class="form-row"><input type="text" name="full_name" placeholder="Full Name" required></div>
            <div class="form-row"><input type="email" name="email" placeholder="Email" required></div>
            <div class="form-row"><input type="text" name="phone" placeholder="Phone"></div>
            <div class="form-row"><input type="password" name="password" placeholder="Password" required></div>
            <button type="submit" class="btn" style="width:100%; margin-top:10px;">Add Student</button>
        </form>
    </div>
</div>

<!-- ================= EDIT STUDENT MODAL ================= -->
<div class="modal-bg" id="editStudentModal">
    <div class="modal">
        <span class="close-modal" onclick="document.getElementById('editStudentModal').classList.remove('active')">✕</span>
        <h3>Edit Student</h3>
        <form method="POST">
            <input type="hidden" name="action" value="edit_student">
            <input type="hidden" name="id" id="edit_student_id">
            <div class="form-row"><input type="text" name="full_name" id="edit_student_name" placeholder="Full Name" required></div>
            <div class="form-row"><input type="email" name="email" id="edit_student_email" placeholder="Email" required></div>
            <div class="form-row"><input type="text" name="phone" id="edit_student_phone" placeholder="Phone"></div>
            <div class="form-row"><input type="password" name="password" placeholder="New Password (leave blank to keep current)"></div>
            <button type="submit" class="btn" style="width:100%; margin-top:10px;">Save Changes</button>
        </form>
    </div>
</div>

<!-- ================= ADD ADMIN MODAL ================= -->
<div class="modal-bg" id="addAdminModal">
    <div class="modal">
        <span class="close-modal" onclick="document.getElementById('addAdminModal').classList.remove('active')">✕</span>
        <h3>Add Admin</h3>
        <form method="POST">
            <input type="hidden" name="action" value="add_admin">
            <div class="form-row"><input type="text" name="username" placeholder="Username" required></div>
            <div class="form-row"><input type="text" name="full_name" placeholder="Full Name" required></div>
            <div class="form-row"><input type="email" name="email" placeholder="Email" required></div>
            <div class="form-row"><input type="password" name="password" placeholder="Password" required></div>
            <button type="submit" class="btn" style="width:100%; margin-top:10px;">Add Admin</button>
        </form>
    </div>
</div>

<!-- ================= EDIT ADMIN MODAL ================= -->
<div class="modal-bg" id="editAdminModal">
    <div class="modal">
        <span class="close-modal" onclick="document.getElementById('editAdminModal').classList.remove('active')">✕</span>
        <h3>Edit Admin</h3>
        <form method="POST">
            <input type="hidden" name="action" value="edit_admin">
            <input type="hidden" name="id" id="edit_admin_id">
            <div class="form-row"><input type="text" name="full_name" id="edit_admin_name" placeholder="Full Name" required></div>
            <div class="form-row"><input type="email" name="email" id="edit_admin_email" placeholder="Email" required></div>
            <div class="form-row"><input type="password" name="password" placeholder="New Password (leave blank to keep current)"></div>
            <button type="submit" class="btn" style="width:100%; margin-top:10px;">Save Changes</button>
        </form>
    </div>
</div>

<script>
function openEditStudent(s) {
    document.getElementById('edit_student_id').value = s.id;
    document.getElementById('edit_student_name').value = s.full_name;
    document.getElementById('edit_student_email').value = s.email;
    document.getElementById('edit_student_phone').value = s.phone;
    document.getElementById('editStudentModal').classList.add('active');
}
function openEditAdmin(a) {
    document.getElementById('edit_admin_id').value = a.id;
    document.getElementById('edit_admin_name').value = a.full_name;
    document.getElementById('edit_admin_email').value = a.email;
    document.getElementById('editAdminModal').classList.add('active');
}
</script>
</body>
</html>
