<?php
require_once 'config.php';

// Check if user is admin
if (!isAdmin()) {
    header('Location: admin_login.php');
    exit();
}

$success = '';
$error = '';
$show_form = false;

// Get all admins
$admins_query = "SELECT * FROM admins ORDER BY created_at DESC";
$admins_result = mysqli_query($conn, $admins_query);

// Handle add new admin
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_admin'])) {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $email = sanitize($_POST['email']);
    $name = sanitize($_POST['name']);
    $phone = sanitize($_POST['phone']);
    
    // Validation
    if (empty($username) || empty($password) || empty($email) || empty($name)) {
        $error = "Please fill all required fields!";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long!";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } else {
        // Check if username already exists
        $check_query = "SELECT * FROM admins WHERE username = ? OR email = ?";
        $check_stmt = mysqli_prepare($conn, $check_query);
        mysqli_stmt_bind_param($check_stmt, "ss", $username, $email);
        mysqli_stmt_execute($check_stmt);
        $check_result = mysqli_stmt_get_result($check_stmt);
        
        if (mysqli_num_rows($check_result) > 0) {
            $error = "Username or Email already exists!";
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert new admin
            $insert_query = "INSERT INTO admins (username, password, email, name, phone, status) VALUES (?, ?, ?, ?, ?, 'active')";
            $insert_stmt = mysqli_prepare($conn, $insert_query);
            mysqli_stmt_bind_param($insert_stmt, "sssss", $username, $hashed_password, $email, $name, $phone);
            
            if (mysqli_stmt_execute($insert_stmt)) {
                $success = "✓ New admin account created successfully!";
                $_POST = array();
                $show_form = false;
            } else {
                $error = "Error creating admin: " . mysqli_error($conn);
            }
            
            mysqli_stmt_close($insert_stmt);
        }
        
        mysqli_stmt_close($check_stmt);
    }
}

// Handle delete admin
if (isset($_GET['delete']) && isAdmin()) {
    $admin_id = intval($_GET['delete']);
    
    // Don't allow deleting the current admin
    if ($admin_id == $_SESSION['user_id']) {
        $error = "You cannot delete your own account!";
    } else {
        $delete_query = "DELETE FROM admins WHERE id = ?";
        $delete_stmt = mysqli_prepare($conn, $delete_query);
        mysqli_stmt_bind_param($delete_stmt, "i", $admin_id);
        
        if (mysqli_stmt_execute($delete_stmt)) {
            $success = "Admin account deleted successfully!";
        } else {
            $error = "Error deleting admin!";
        }
        
        mysqli_stmt_close($delete_stmt);
    }
}

// Re-fetch admins after any operation
$admins_result = mysqli_query($conn, $admins_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Admin Accounts</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: white;
            text-decoration: none;
            font-weight: 600;
            padding: 10px 20px;
            background: rgba(255,255,255,0.2);
            border-radius: 8px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            flex-wrap: wrap;
            gap: 15px;
        }

        .header h1 {
            color: #333;
        }

        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: transform 0.2s;
        }

        .btn:hover {
            transform: scale(1.02);
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
            padding: 8px 15px;
            font-size: 0.9em;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }

        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid #ef4444;
        }

        .form-container {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            display: none;
        }

        .form-container.show {
            display: block;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .form-group label {
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }

        .form-group label .required {
            color: #ef4444;
        }

        .form-group input {
            padding: 10px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 1em;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
        }

        .btn-group {
            display: flex;
            gap: 10px;
        }

        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }

        .table-container {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #e5e7eb;
        }

        tbody tr:hover {
            background: #f9fafb;
        }

        .status-active {
            background: #d1fae5;
            color: #065f46;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 600;
        }

        .no-admins {
            text-align: center;
            padding: 40px;
            color: #6b7280;
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="admin_dashboard.php" class="back-link">← Back to Dashboard</a>

        <div class="header">
            <h1>👤 Manage Admin Accounts</h1>
            <button onclick="toggleForm()" class="btn btn-primary">+ Add New Admin</button>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <span>✓</span> <?php echo $success; ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error">
                <span>✕</span> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <div class="form-container <?php echo $show_form ? 'show' : ''; ?>" id="formContainer">
            <h2 style="margin-bottom: 20px; color: #333;">Create New Admin Account</h2>
            <form method="POST" action="">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Full Name <span class="required">*</span></label>
                        <input type="text" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Username <span class="required">*</span></label>
                        <input type="text" name="username" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Email <span class="required">*</span></label>
                        <input type="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Phone</label>
                        <input type="tel" name="phone" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                    </div>

                    <div class="form-group">
                        <label>Password <span class="required">*</span></label>
                        <input type="password" name="password" id="password" required>
                        <small style="color: #6b7280; margin-top: 5px;">Min 6 characters</small>
                    </div>

                    <div class="form-group">
                        <label>Confirm Password <span class="required">*</span></label>
                        <input type="password" name="confirm_password" required>
                    </div>
                </div>

                <div class="btn-group">
                    <button type="submit" name="add_admin" class="btn btn-primary">✓ Create Admin</button>
                    <button type="button" onclick="toggleForm()" class="btn btn-secondary">Cancel</button>
                </div>
            </form>
        </div>

        <div class="table-container">
            <h2 style="padding: 20px 20px 0; color: #333;">All Admin Accounts</h2>
            <?php if (mysqli_num_rows($admins_result) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Full Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Created</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($admin = mysqli_fetch_assoc($admins_result)): ?>
                            <tr>
                                <td>#<?php echo $admin['id']; ?></td>
                                <td><strong><?php echo htmlspecialchars($admin['name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($admin['username']); ?></td>
                                <td><?php echo htmlspecialchars($admin['email']); ?></td>
                                <td><?php echo htmlspecialchars($admin['phone'] ?? '-'); ?></td>
                                <td><?php echo formatDate($admin['created_at']); ?></td>
                                <td>
                                    <span class="status-active">Active</span>
                                </td>
                                <td>
                                    <?php if ($admin['id'] != $_SESSION['user_id']): ?>
                                        <a href="?delete=<?php echo $admin['id']; ?>" class="btn btn-danger" onclick="return confirm('Delete this admin?')">Delete</a>
                                    <?php else: ?>
                                        <span style="color: #6b7280;">Current Admin</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-admins">
                    <p>No admin accounts found</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function toggleForm() {
            const form = document.getElementById('formContainer');
            form.classList.toggle('show');
        }
    </script>
</body>
</html>

<?php mysqli_close($conn); ?>