<?php
require_once 'config.php';

// Check if admin is logged in
if (!isAdmin()) {
    header('Location: admin_login.php');
    exit();
}

$success = '';
$error = '';
$keep_form_data = false; // Control whether to keep form data

// Get categories and authors for dropdowns
$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");
$authors = mysqli_query($conn, "SELECT * FROM authors ORDER BY name");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_book'])) {
    $title = sanitize($_POST['title']);
    $author_id = intval($_POST['author_id']);
    $category_id = intval($_POST['category_id']);
    $isbn = sanitize($_POST['isbn']);
    $quantity = intval($_POST['quantity']);
    $available = intval($_POST['available']);
    $description = isset($_POST['description']) ? sanitize($_POST['description']) : '';
    $publication_year = !empty($_POST['publication_year']) ? intval($_POST['publication_year']) : null;
    
    // Validate inputs
    if (empty($title) || $author_id == 0 || $category_id == 0) {
        $error = "Please fill all required fields!";
        $keep_form_data = true; // Keep the data they entered
    } elseif ($available > $quantity) {
        $error = "Available copies cannot exceed total quantity!";
        $keep_form_data = true; // Keep the data they entered
    } else {
        // Insert book (duplicate ISBNs allowed)
        if ($publication_year) {
            $query = "INSERT INTO books (title, author_id, category_id, isbn, quantity, available, description, publication_year) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "siisiiis", $title, $author_id, $category_id, $isbn, $quantity, $available, $description, $publication_year);
        } else {
            $query = "INSERT INTO books (title, author_id, category_id, isbn, quantity, available, description) 
                      VALUES (?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "siisiis", $title, $author_id, $category_id, $isbn, $quantity, $available, $description);
        }
        
        if (mysqli_stmt_execute($stmt)) {
            $book_id = mysqli_insert_id($conn);
            $success = "✓ Book added successfully! (ID: #$book_id) You can add another book below.";
            // Clear form data only on success
            $_POST = array();
            $keep_form_data = false;
        } else {
            $error = "Error adding book: " . mysqli_error($conn);
            $keep_form_data = true; // Keep the data they entered
        }
        
        mysqli_stmt_close($stmt);
    }
}

// Reset dropdowns for re-query
$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");
$authors = mysqli_query($conn, "SELECT * FROM authors ORDER BY name");

// Helper function to retain form values
function getPostValue($key, $default = '') {
    global $keep_form_data;
    if ($keep_form_data && isset($_POST[$key])) {
        return htmlspecialchars($_POST[$key]);
    }
    return $default;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Book - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: white;
            text-decoration: none;
            font-weight: 600;
            padding: 10px 20px;
            background: rgba(255,255,255,0.2);
            border-radius: 8px;
            transition: background 0.3s;
        }

        .back-link:hover {
            background: rgba(255,255,255,0.3);
        }

        .form-container {
            background: white;
            padding: 35px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .form-container h1 {
            color: #333;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-note {
            background: #e0e7ff;
            color: #4338ca;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            font-size: 0.9em;
            display: flex;
            align-items: start;
            gap: 10px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }

        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid #ef4444;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .form-group label {
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            font-size: 0.95em;
        }

        .form-group label .required {
            color: #ef4444;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            padding: 12px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 1em;
            font-family: inherit;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .field-note {
            font-size: 0.85em;
            color: #6b7280;
            margin-top: 5px;
        }

        .isbn-note {
            font-size: 0.85em;
            color: #10b981;
            margin-top: 5px;
            font-weight: 500;
        }

        .btn-group {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }

        .btn {
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            font-size: 1em;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            flex: 1;
        }

        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }

        .btn-secondary:hover {
            background: #d1d5db;
        }

        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }

            .btn-group {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="admin_dashboard.php" class="back-link">← Back to Dashboard</a>

        <div class="form-container">
            <h1>📚 Add New Book</h1>
            
            <div class="form-note">
                <span style="font-size: 1.2em;">ℹ️</span>
                <div>
                    <strong>ISBN Duplication Allowed:</strong> You can add multiple books with the same ISBN. 
                    This is useful for different editions, multiple copies, or replacement books.
                </div>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <span style="font-size: 1.3em;">✓</span>
                    <span><?php echo $success; ?></span>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <span style="font-size: 1.3em;">✕</span>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-grid">
                    <div class="form-group full-width">
                        <label>Book Title <span class="required">*</span></label>
                        <input 
                            type="text" 
                            name="title" 
                            value="<?php echo getPostValue('title'); ?>" 
                            placeholder="Enter book title"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label>Author <span class="required">*</span></label>
                        <select name="author_id" required>
                            <option value="">-- Select Author --</option>
                            <?php 
                            $selected_author = getPostValue('author_id');
                            while ($author = mysqli_fetch_assoc($authors)): 
                                $author_name = $author['name'] ?? $author['author_name'] ?? $author['full_name'] ?? 'Unknown';
                                $selected = ($selected_author == $author['id']) ? 'selected' : '';
                            ?>
                                <option value="<?php echo $author['id']; ?>" <?php echo $selected; ?>>
                                    <?php echo htmlspecialchars($author_name); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Category <span class="required">*</span></label>
                        <select name="category_id" required>
                            <option value="">-- Select Category --</option>
                            <?php 
                            $selected_category = getPostValue('category_id');
                            while ($category = mysqli_fetch_assoc($categories)): 
                                $selected = ($selected_category == $category['id']) ? 'selected' : '';
                            ?>
                                <option value="<?php echo $category['id']; ?>" <?php echo $selected; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>ISBN</label>
                        <input 
                            type="text" 
                            name="isbn" 
                            value="<?php echo getPostValue('isbn'); ?>" 
                            placeholder="978-0-123456-78-9"
                        >
                        <div class="isbn-note">✓ Duplicates allowed</div>
                    </div>

                    <div class="form-group">
                        <label>Publication Year</label>
                        <input 
                            type="number" 
                            name="publication_year" 
                            value="<?php echo getPostValue('publication_year'); ?>" 
                            min="1800" 
                            max="<?php echo date('Y'); ?>" 
                            placeholder="<?php echo date('Y'); ?>"
                        >
                    </div>

                    <div class="form-group">
                        <label>Total Quantity <span class="required">*</span></label>
                        <input 
                            type="number" 
                            name="quantity" 
                            value="<?php echo getPostValue('quantity', '1'); ?>" 
                            min="1" 
                            placeholder="1"
                            required
                        >
                        <div class="field-note">Total number of copies</div>
                    </div>

                    <div class="form-group">
                        <label>Available Copies <span class="required">*</span></label>
                        <input 
                            type="number" 
                            name="available" 
                            value="<?php echo getPostValue('available', '1'); ?>" 
                            min="0" 
                            placeholder="1"
                            required
                        >
                        <div class="field-note">Available for borrowing</div>
                    </div>

                    <div class="form-group full-width">
                        <label>Description</label>
                        <textarea 
                            name="description" 
                            placeholder="Brief description of the book (optional)..."
                        ><?php echo getPostValue('description'); ?></textarea>
                    </div>
                </div>

                <div class="btn-group">
                    <button type="submit" name="add_book" class="btn btn-primary">
                        <span>✓</span>
                        <span>Add Book to Library</span>
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <span>↻</span>
                        <span>Clear Form</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

<?php mysqli_close($conn); ?>