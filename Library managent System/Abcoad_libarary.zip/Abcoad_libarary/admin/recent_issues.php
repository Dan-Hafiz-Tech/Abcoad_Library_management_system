<?php
require_once 'config.php';

// Check if admin is logged in
if (!isAdmin()) {
    header('Location: admin_login.php');
    exit();
}

// Get filter parameters
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

// Base query - FIXED
$query = "SELECT ib.*, b.title, b.isbn, b.author_id,
          s.name as student_name, s.student_id, s.email as student_email,
          DATEDIFF(CURDATE(), ib.issue_date) as days_issued,
          DATEDIFF(ib.due_date, CURDATE()) as days_until_due
          FROM issued_books ib
          JOIN books b ON ib.book_id = b.id
          JOIN students s ON ib.student_id = s.id
          WHERE 1=1";

// Apply filters
if ($filter == 'active') {
    $query .= " AND ib.return_date IS NULL";
} elseif ($filter == 'returned') {
    $query .= " AND ib.return_date IS NOT NULL";
} elseif ($filter == 'overdue') {
    $query .= " AND ib.return_date IS NULL AND ib.due_date < CURDATE()";
} elseif ($filter == 'due_soon') {
    $query .= " AND ib.return_date IS NULL AND ib.due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY)";
}

// Apply search
if ($search) {
    $query .= " AND (b.title LIKE '%$search%' 
                OR s.name LIKE '%$search%' 
                OR s.student_id LIKE '%$search%'
                OR b.isbn LIKE '%$search%')";
}

$query .= " ORDER BY ib.issue_date DESC LIMIT 100";

$result = mysqli_query($conn, $query);

// Fetch data and add author names
$issues_data = [];
while ($row = mysqli_fetch_assoc($result)) {
    // Get author name
    $author_query = "SELECT * FROM authors WHERE id = ?";
    $author_stmt = mysqli_prepare($conn, $author_query);
    mysqli_stmt_bind_param($author_stmt, "i", $row['author_id']);
    mysqli_stmt_execute($author_stmt);
    $author_result = mysqli_stmt_get_result($author_stmt);
    $author = mysqli_fetch_assoc($author_result);
    
    $row['author_name'] = $author['name'] ?? $author['author_name'] ?? $author['full_name'] ?? 'Unknown';
    
    $issues_data[] = $row;
    mysqli_stmt_close($author_stmt);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recent Issues - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: white;
            text-decoration: none;
            font-weight: 600;
            padding: 10px 20px;
            background: rgba(255,255,255,0.2);
            border-radius: 8px;
            transition: background 0.3s;
        }

        .back-link:hover {
            background: rgba(255,255,255,0.3);
        }

        .header {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .header h1 {
            color: #333;
            margin-bottom: 15px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-3px);
        }

        .stat-number {
            font-size: 2.5em;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #6b7280;
            font-size: 0.9em;
            font-weight: 600;
        }

        .stat-total { color: #667eea; }
        .stat-active { color: #10b981; }
        .stat-returned { color: #6b7280; }
        .stat-overdue { color: #ef4444; }
        .stat-due-soon { color: #f59e0b; }

        .filters-section {
            background: white;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .filters-row {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }

        .filter-group {
            flex: 1;
            min-width: 200px;
        }

        .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }

        .filter-group input,
        .filter-group select {
            width: 100%;
            padding: 10px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 1em;
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
            text-decoration: none;
            display: inline-block;
        }

        .btn:hover {
            transform: scale(1.02);
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }

        .filter-tags {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }

        .filter-tag {
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9em;
            font-weight: 600;
            text-decoration: none;
            transition: transform 0.2s;
        }

        .filter-tag:hover {
            transform: scale(1.05);
        }

        .filter-tag.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .filter-tag.inactive {
            background: #f3f4f6;
            color: #6b7280;
        }

        .table-container {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 0.9em;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #e5e7eb;
        }

        tbody tr:hover {
            background: #f9fafb;
        }

        tbody tr:last-child td {
            border-bottom: none;
        }

        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 600;
            display: inline-block;
        }

        .status-active {
            background: #d1fae5;
            color: #065f46;
        }

        .status-returned {
            background: #e5e7eb;
            color: #374151;
        }

        .status-overdue {
            background: #fee2e2;
            color: #991b1b;
        }

        .status-due-soon {
            background: #fef3c7;
            color: #92400e;
        }

        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }

        .no-data h2 {
            margin-bottom: 10px;
        }

        .action-link {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }

        .action-link:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 800px;
            }

            .filters-row {
                flex-direction: column;
            }

            .filter-group {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="admin_dashboard.php" class="back-link">← Back to Dashboard</a>

        <div class="header">
            <h1>📋 Recent Book Issues</h1>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number stat-total"><?php echo $stats['total_issues']; ?></div>
                <div class="stat-label">Total Issues</div>
            </div>
            <div class="stat-card">
                <div class="stat-number stat-active"><?php echo $stats['active_issues']; ?></div>
                <div class="stat-label">Currently Active</div>
            </div>
            <div class="stat-card">
                <div class="stat-number stat-overdue"><?php echo $stats['overdue_issues']; ?></div>
                <div class="stat-label">Overdue</div>
            </div>
            <div class="stat-card">
                <div class="stat-number stat-due-soon"><?php echo $stats['due_soon']; ?></div>
                <div class="stat-label">Due in 3 Days</div>
            </div>
            <div class="stat-card">
                <div class="stat-number stat-returned"><?php echo $stats['returned_issues']; ?></div>
                <div class="stat-label">Returned</div>
            </div>
        </div>

        <div class="filters-section">
            <div class="filter-tags">
                <a href="?filter=all" class="filter-tag <?php echo ($filter == 'all') ? 'active' : 'inactive'; ?>">
                    All Issues
                </a>
                <a href="?filter=active" class="filter-tag <?php echo ($filter == 'active') ? 'active' : 'inactive'; ?>">
                    Active
                </a>
                <a href="?filter=overdue" class="filter-tag <?php echo ($filter == 'overdue') ? 'active' : 'inactive'; ?>">
                    Overdue
                </a>
                <a href="?filter=due_soon" class="filter-tag <?php echo ($filter == 'due_soon') ? 'active' : 'inactive'; ?>">
                    Due Soon
                </a>
                <a href="?filter=returned" class="filter-tag <?php echo ($filter == 'returned') ? 'active' : 'inactive'; ?>">
                    Returned
                </a>
            </div>

            <form method="GET" action="">
                <input type="hidden" name="filter" value="<?php echo htmlspecialchars($filter); ?>">
                <div class="filters-row">
                    <div class="filter-group">
                        <label>Search</label>
                        <input type="text" name="search" placeholder="Book title, Student name, ID..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="filter-buttons" style="align-self: flex-end;">
                        <button type="submit" class="btn btn-primary">🔍 Search</button>
                        <a href="recent_issues.php" class="btn btn-secondary">Clear</a>
                    </div>
                </div>
            </form>
        </div>

        <div class="table-container">
            <?php if (mysqli_num_rows($result) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Book Title</th>
                            <th>Student</th>
                            <th>Issue Date</th>
                            <th>Due Date</th>
                            <th>Return Date</th>
                            <th>Status</th>
                            <th>Days</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): 
                            // Determine status
                            if ($row['return_date']) {
                                $status_class = 'returned';
                                $status_text = 'Returned';
                                $days_info = 'Returned on ' . formatDate($row['return_date']);
                            } elseif ($row['days_until_due'] < 0) {
                                $status_class = 'overdue';
                                $status_text = 'Overdue';
                                $days_info = abs($row['days_until_due']) . ' days overdue';
                            } elseif ($row['days_until_due'] <= 3) {
                                $status_class = 'due-soon';
                                $status_text = 'Due Soon';
                                $days_info = $row['days_until_due'] . ' days left';
                            } else {
                                $status_class = 'active';
                                $status_text = 'Active';
                                $days_info = $row['days_until_due'] . ' days left';
                            }
                        ?>
                            <tr>
                                <td><strong>#<?php echo $row['id']; ?></strong></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($row['title']); ?></strong><br>
                                    <small style="color: #6b7280;">by <?php echo htmlspecialchars($row['author_name']); ?></small><br>
                                    <small style="color: #9ca3af;">ISBN: <?php echo htmlspecialchars($row['isbn']); ?></small>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars($row['student_name']); ?></strong><br>
                                    <small style="color: #6b7280;"><?php echo htmlspecialchars($row['student_id']); ?></small><br>
                                    <small style="color: #9ca3af;"><?php echo htmlspecialchars($row['student_email']); ?></small>
                                </td>
                                <td><?php echo formatDate($row['issue_date']); ?></td>
                                <td><?php echo formatDate($row['due_date']); ?></td>
                                <td>
                                    <?php echo $row['return_date'] ? formatDate($row['return_date']) : '-'; ?>
                                </td>
                                <td>
                                    <span class="status-badge status-<?php echo $status_class; ?>">
                                        <?php echo $status_text; ?>
                                    </span>
                                </td>
                                <td><?php echo $days_info; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-data">
                    <h2>📚 No Issues Found</h2>
                    <p>No book issues match your current filter.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

<?php mysqli_close($conn); ?>