<?php
// admin/manage_requests.php
require_once 'config.php';

if (!isAdmin()) {
    header('Location: admin_login.php');
    exit();
}

$success = '';
$error = '';

// Handle approve / reject actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $request_id = intval($_POST['request_id']);
    $admin_note = isset($_POST['admin_response']) ? sanitize($_POST['admin_response']) : '';

    // Load the request
    $stmt = mysqli_prepare($conn, "SELECT * FROM book_requests WHERE id = ? AND status = 'pending'");
    mysqli_stmt_bind_param($stmt, "i", $request_id);
    mysqli_stmt_execute($stmt);
    $request_row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$request_row) {
        $error = "Request not found or already processed.";

    } elseif ($_POST['action'] === 'approve') {

        if ($request_row['request_type'] === 'borrow') {
            // ---- Approve a BORROW request ----
            $book_stmt = mysqli_prepare($conn, "SELECT available_quantity FROM books WHERE id = ?");
            mysqli_stmt_bind_param($book_stmt, "i", $request_row['book_id']);
            mysqli_stmt_execute($book_stmt);
            $book_row = mysqli_fetch_assoc(mysqli_stmt_get_result($book_stmt));

            if (!$book_row || $book_row['available_quantity'] <= 0) {
                $error = "Cannot approve: no available copies of this book left.";
            } else {
                mysqli_begin_transaction($conn);
                try {
                    $upd = mysqli_prepare($conn, "UPDATE book_requests SET status='approved', admin_response=?, response_date=NOW() WHERE id=?");
                    mysqli_stmt_bind_param($upd, "si", $admin_note, $request_id);
                    mysqli_stmt_execute($upd);

                    $issue_date = date('Y-m-d');
                    $due_date = date('Y-m-d', strtotime('+14 days'));
                    $issue = mysqli_prepare($conn, "INSERT INTO issued_books (request_id, book_id, student_id, issue_date, due_date, status) VALUES (?, ?, ?, ?, ?, 'issued')");
                    mysqli_stmt_bind_param($issue, "iiiss", $request_id, $request_row['book_id'], $request_row['student_id'], $issue_date, $due_date);
                    mysqli_stmt_execute($issue);

                    $dec = mysqli_prepare($conn, "UPDATE books SET available_quantity = available_quantity - 1 WHERE id = ? AND available_quantity > 0");
                    mysqli_stmt_bind_param($dec, "i", $request_row['book_id']);
                    mysqli_stmt_execute($dec);

                    mysqli_commit($conn);
                    $success = "Borrow request approved and book issued.";
                } catch (Exception $e) {
                    mysqli_rollback($conn);
                    $error = "Error approving borrow request: " . $e->getMessage();
                }
            }

        } else {
            // ---- Approve a RETURN request ----
            $ib_stmt = mysqli_prepare($conn, "SELECT * FROM issued_books WHERE id = ? AND return_date IS NULL AND status = 'issued'");
            mysqli_stmt_bind_param($ib_stmt, "i", $request_row['issued_book_id']);
            mysqli_stmt_execute($ib_stmt);
            $issued_row = mysqli_fetch_assoc(mysqli_stmt_get_result($ib_stmt));

            if (!$issued_row) {
                $error = "Cannot approve: this book is no longer marked as issued.";
            } else {
                mysqli_begin_transaction($conn);
                try {
                    $upd = mysqli_prepare($conn, "UPDATE book_requests SET status='approved', admin_response=?, response_date=NOW() WHERE id=?");
                    mysqli_stmt_bind_param($upd, "si", $admin_note, $request_id);
                    mysqli_stmt_execute($upd);

                    $return_date = date('Y-m-d');
                    $mark_returned = mysqli_prepare($conn, "UPDATE issued_books SET return_date = ?, status = 'returned' WHERE id = ?");
                    mysqli_stmt_bind_param($mark_returned, "si", $return_date, $issued_row['id']);
                    mysqli_stmt_execute($mark_returned);

                    $inc = mysqli_prepare($conn, "UPDATE books SET available_quantity = available_quantity + 1 WHERE id = ?");
                    mysqli_stmt_bind_param($inc, "i", $issued_row['book_id']);
                    mysqli_stmt_execute($inc);

                    mysqli_commit($conn);
                    $success = "Return confirmed. Book is back in the catalog.";
                } catch (Exception $e) {
                    mysqli_rollback($conn);
                    $error = "Error confirming return: " . $e->getMessage();
                }
            }
        }

    } elseif ($_POST['action'] === 'reject') {
        $upd = mysqli_prepare($conn, "UPDATE book_requests SET status='rejected', admin_response=?, response_date=NOW() WHERE id=?");
        mysqli_stmt_bind_param($upd, "si", $admin_note, $request_id);
        if (mysqli_stmt_execute($upd)) {
            $success = ($request_row['request_type'] === 'return') ? "Return request rejected." : "Borrow request rejected.";
        } else {
            $error = "Error rejecting request: " . mysqli_error($conn);
        }
    }
}

// Fetch pending requests (both types) with student + book info
$pending = mysqli_query($conn, "
    SELECT br.id, br.request_date, br.request_type, s.full_name AS student_name, s.student_id AS student_code,
           b.title AS book_title, b.available_quantity,
           ib.due_date AS issued_due_date
    FROM book_requests br
    JOIN students s ON br.student_id = s.id
    JOIN books b ON br.book_id = b.id
    LEFT JOIN issued_books ib ON br.issued_book_id = ib.id
    WHERE br.status = 'pending'
    ORDER BY br.request_date ASC
");

// Fetch recently processed requests (approved/rejected) for reference
$recent = mysqli_query($conn, "
    SELECT br.id, br.status, br.request_type, br.response_date, br.admin_response,
           s.full_name AS student_name, b.title AS book_title
    FROM book_requests br
    JOIN students s ON br.student_id = s.id
    JOIN books b ON br.book_id = b.id
    WHERE br.status IN ('approved','rejected')
    ORDER BY br.response_date DESC
    LIMIT 15
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Book Requests</title>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background:#f4f6f8; padding:30px; }
    .container { max-width:1150px; margin:0 auto; }
    h1 { color:#333; margin-bottom:20px; }
    h2 { color:#444; margin:30px 0 15px; }
    .btn { display:inline-block; padding:8px 16px; background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);
           color:#fff; border:none; border-radius:6px; cursor:pointer; text-decoration:none; font-size:0.9em; }
    .btn-approve { background:#10b981; }
    .btn-reject { background:#e74c3c; }
    .btn-small { padding:6px 14px; font-size:0.85em; margin-right:5px; }
    .card { background:#fff; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.08); padding:20px; margin-bottom:20px; }
    table { width:100%; border-collapse:collapse; margin-top:10px; }
    th, td { text-align:left; padding:10px; border-bottom:1px solid #eee; font-size:0.9em; vertical-align:top; }
    th { background:#f8f9fa; color:#555; }
    .alert-error { background:#fee; color:#c33; border:1px solid #fcc; padding:12px; border-radius:8px; margin-bottom:20px; }
    .alert-success { background:#e8f8ef; color:#27ae60; border:1px solid #b7ebc6; padding:12px; border-radius:8px; margin-bottom:20px; }
    .top-actions { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; }
    .note-input { width:150px; padding:6px; border:1px solid #ddd; border-radius:6px; font-size:0.85em; margin-right:5px; }
    .status-badge { padding:4px 10px; border-radius:12px; font-size:0.8em; font-weight:600; }
    .status-approved { background:#d1fae5; color:#065f46; }
    .status-rejected { background:#fee2e2; color:#991b1b; }
    .type-badge { padding:4px 10px; border-radius:12px; font-size:0.8em; font-weight:600; }
    .type-borrow { background:#e0e7ff; color:#4338ca; }
    .type-return { background:#fef3c7; color:#92400e; }
    .empty { color:#888; text-align:center; padding:20px; }
</style>
</head>
<body>
<div class="container">

    <div class="top-actions">
        <h1>Manage Book Requests</h1>
        <a href="admin_dashboard.php" class="btn">← Back to Dashboard</a>
    </div>

    <?php if ($error): ?><div class="alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert-success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>

    <!-- ============= PENDING REQUESTS ============= -->
    <div class="card">
        <h2 style="margin-top:0;">Pending Requests</h2>
        <table>
            <thead><tr><th>Type</th><th>Requested</th><th>Student</th><th>Book</th><th>Info</th><th>Actions</th></tr></thead>
            <tbody>
            <?php if (mysqli_num_rows($pending) === 0): ?>
                <tr><td colspan="6" class="empty">No pending requests.</td></tr>
            <?php else: ?>
                <?php while ($r = mysqli_fetch_assoc($pending)): ?>
                    <tr>
                        <td>
                            <span class="type-badge <?php echo $r['request_type'] === 'return' ? 'type-return' : 'type-borrow'; ?>">
                                <?php echo $r['request_type'] === 'return' ? '📗 Return' : '📖 Borrow'; ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($r['request_date']); ?></td>
                        <td><?php echo htmlspecialchars($r['student_name']); ?> (<?php echo htmlspecialchars($r['student_code']); ?>)</td>
                        <td><?php echo htmlspecialchars($r['book_title']); ?></td>
                        <td>
                            <?php if ($r['request_type'] === 'return'): ?>
                                Due: <?php echo $r['issued_due_date'] ? date('M d, Y', strtotime($r['issued_due_date'])) : '—'; ?>
                            <?php else: ?>
                                Copies left: <?php echo (int)$r['available_quantity']; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="POST" style="display:flex; gap:5px; flex-wrap:wrap;">
                                <input type="hidden" name="request_id" value="<?php echo $r['id']; ?>">
                                <input type="text" name="admin_response" class="note-input" placeholder="Optional note">
                                <button type="submit" name="action" value="approve" class="btn btn-small btn-approve" onclick="return confirm('Approve this request?');">Approve</button>
                                <button type="submit" name="action" value="reject" class="btn btn-small btn-reject" onclick="return confirm('Reject this request?');">Reject</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- ============= RECENTLY PROCESSED ============= -->
    <div class="card">
        <h2 style="margin-top:0;">Recently Processed</h2>
        <table>
            <thead><tr><th>Date</th><th>Type</th><th>Student</th><th>Book</th><th>Status</th><th>Note</th></tr></thead>
            <tbody>
            <?php if (mysqli_num_rows($recent) === 0): ?>
                <tr><td colspan="6" class="empty">No processed requests yet.</td></tr>
            <?php else: ?>
                <?php while ($r = mysqli_fetch_assoc($recent)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($r['response_date']); ?></td>
                        <td>
                            <span class="type-badge <?php echo $r['request_type'] === 'return' ? 'type-return' : 'type-borrow'; ?>">
                                <?php echo $r['request_type'] === 'return' ? '📗 Return' : '📖 Borrow'; ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($r['student_name']); ?></td>
                        <td><?php echo htmlspecialchars($r['book_title']); ?></td>
                        <td><span class="status-badge status-<?php echo $r['status']; ?>"><?php echo ucfirst($r['status']); ?></span></td>
                        <td><?php echo htmlspecialchars($r['admin_response']); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
</body>
</html>
<?php mysqli_close($conn); ?>
