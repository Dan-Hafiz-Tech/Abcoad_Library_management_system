<?php
require_once 'config.php';

$success = '';
$error = '';
$step = isset($_GET['step']) ? $_GET['step'] : 1;
$token = isset($_GET['token']) ? sanitize($_GET['token']) : '';

// Step 1: Request password reset
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['request_reset'])) {
    $email = sanitize($_POST['email']);
    $user_type = sanitize($_POST['user_type']);
    
    if ($user_type == 'admin') {
        $query = "SELECT * FROM admins WHERE email = ?";
    } else {
        $query = "SELECT * FROM students WHERE email = ?";
    }
    
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($user = mysqli_fetch_assoc($result)) {
        // Generate token
        $token = bin2hex(random_bytes(50));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        $user_id = ($user_type == 'admin') ? $user['id'] : $user['id'];
        
        // Save token to database
        $insert_query = "INSERT INTO forgot_password (user_id, user_type, token, email, expires_at) VALUES (?, ?, ?, ?, ?)";
        $insert_stmt = mysqli_prepare($conn, $insert_query);
        mysqli_stmt_bind_param($insert_stmt, "sssss", $user_id, $user_type, $token, $email, $expires);
        
        if (mysqli_stmt_execute($insert_stmt)) {
            $success = "✓ Password reset link has been sent to your email!";
            // In production, send actual email with reset link
            echo "<!-- Password reset link: " . $_SERVER['HTTP_HOST'] . "/forgot_password.php?step=2&token=" . $token . " -->";
        } else {
            $error = "Error processing request!";
        }
        
        mysqli_stmt_close($insert_stmt);
    } else {
        $error = "Email not found in our system!";
    }
    
    mysqli_stmt_close($stmt);
}

// Step 2: Reset password with token
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reset_password'])) {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if (strlen($new_password) < 6) {
        $error = "Password must be at least 6 characters!";
    } elseif ($new_password !== $confirm_password) {
        $error = "Passwords do not match!";
    } else {
        // Verify token
        $token_query = "SELECT * FROM forgot_password WHERE token = ? AND used = 0 AND expires_at > NOW()";
        $token_stmt = mysqli_prepare($conn, $token_query);
        mysqli_stmt_bind_param($token_stmt, "s", $token);
        mysqli_stmt_execute($token_stmt);
        $token_result = mysqli_stmt_get_result($token_stmt);
        
        if ($token_row = mysqli_fetch_assoc($token_result)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            if ($token_row['user_type'] == 'admin') {
                $update_query = "UPDATE admins SET password = ? WHERE id = ?";
            } else {
                $update_query = "UPDATE students SET password = ? WHERE id = ?";
            }
            
            $update_stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($update_stmt, "ss", $hashed_password, $token_row['user_id']);
            
            if (mysqli_stmt_execute($update_stmt)) {
                // Mark token as used
                mysqli_query($conn, "UPDATE forgot_password SET used = 1 WHERE token = '$token'");
                $success = "✓ Password reset successfully! You can now login with your new password.";
                $step = 3;
            } else {
                $error = "Error updating password!";
            }
            
            mysqli_stmt_close($update_stmt);
        } else {
            $error = "Invalid or expired token!";
            $step = 1;
        }
        
        mysqli_stmt_close($token_stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            max-width: 500px;
            width: 100%;
        }

        .form-box {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            color: #333;
            font-size: 2em;
            margin-bottom: 10px;
        }

        .header p {
            color: #6b7280;
        }

        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }

        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid #ef4444;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 1em;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }

        .btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1em;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .btn:hover {
            transform: scale(1.02);
        }

        .links {
            text-align: center;
            margin-top: 20px;
        }

        .links a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }

        .links a:hover {
            text-decoration: underline;
        }

        .success-box {
            text-align: center;
            padding: 40px 20px;
        }

        .success-icon {
            font-size: 4em;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-box">
            <?php if ($step == 1): ?>
                <div class="header">
                    <h1>🔐 Forgot Password</h1>
                    <p>Enter your email to reset your password</p>
                </div>

                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-error"><?php echo $error; ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <label>Account Type</label>
                        <select name="user_type" required>
                            <option value="">Select Account Type</option>
                            <option value="admin">Admin</option>
                            <option value="student">Student</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" name="email" placeholder="your@email.com" required>
                    </div>

                    <button type="submit" name="request_reset" class="btn">Send Reset Link</button>
                </form>

                <div class="links">
                    <a href="admin_login.php">Back to Login</a>
                </div>

            <?php elseif ($step == 2 && $token): ?>
                <div class="header">
                    <h1>🔑 Reset Password</h1>
                    <p>Enter your new password</p>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-error"><?php echo $error; ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" placeholder="At least 6 characters" required>
                    </div>

                    <div class="form-group">
                        <label>Confirm Password</label>
                        <input type="password" name="confirm_password" placeholder="Confirm password" required>
                    </div>

                    <button type="submit" name="reset_password" class="btn">Reset Password</button>
                </form>

            <?php else:?>
                <div class="success-box">
                    <div class="success-icon">✓</div>
                    <h2 style="color: #10b981; margin-bottom: 10px;">Password Reset Successful!</h2>
                    <p style="color: #6b7280; margin-bottom: 20px;">Your password has been reset. You can now login with your new password.</p>
                    <a href="admin_login.php" class="btn" style="text-decoration: none; display: inline-block; width: auto; padding: 12px 30px;">Go to Login</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

<?php mysqli_close($conn); ?>