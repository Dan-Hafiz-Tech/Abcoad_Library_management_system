<?php
require_once 'config.php';

// Check if student is logged in
if (!isStudent()) {
    header('Location: student_login.php');
    exit();
}

$student_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Get student information
$student_query = "SELECT * FROM students WHERE id = ?";
$stmt = mysqli_prepare($conn, $student_query);
mysqli_stmt_bind_param($stmt, "i", $student_id);
mysqli_stmt_execute($stmt);
$student_result = mysqli_stmt_get_result($stmt);
$student = mysqli_fetch_assoc($student_result);

// Count books currently issued (not yet returned)
$issued_query = "SELECT COUNT(*) as count FROM issued_books WHERE student_id = ? AND return_date IS NULL";
$stmt = mysqli_prepare($conn, $issued_query);
mysqli_stmt_bind_param($stmt, "i", $student_id);
mysqli_stmt_execute($stmt);
$issued_count = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['count'];

// Count pending requests (not yet approved/rejected)
$pending_query = "SELECT COUNT(*) as count FROM book_requests WHERE student_id = ? AND status = 'pending'";
$stmt = mysqli_prepare($conn, $pending_query);
mysqli_stmt_bind_param($stmt, "i", $student_id);
mysqli_stmt_execute($stmt);
$pending_count = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['count'];

// Maximum books a student can have issued + pending at once
$max_books = 5;
$active_count = $issued_count + $pending_count;
$can_borrow_more = ($active_count < $max_books);

// Handle borrow request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['borrow_book'])) {
    $book_id = intval($_POST['book_id']);

    if (!$can_borrow_more) {
        $error = "You have reached the maximum limit of $max_books books (issued + pending requests)!";
    } else {
        // Check if book has available copies
        $book_check = "SELECT * FROM books WHERE id = ? AND available_quantity > 0";
        $stmt = mysqli_prepare($conn, $book_check);
        mysqli_stmt_bind_param($stmt, "i", $book_id);
        mysqli_stmt_execute($stmt);
        $book_result = mysqli_stmt_get_result($stmt);

        if ($book = mysqli_fetch_assoc($book_result)) {
            // Check if student already has this book issued
            $already_issued = "SELECT * FROM issued_books WHERE student_id = ? AND book_id = ? AND return_date IS NULL";
            $stmt = mysqli_prepare($conn, $already_issued);
            mysqli_stmt_bind_param($stmt, "ii", $student_id, $book_id);
            mysqli_stmt_execute($stmt);
            $issued_check_result = mysqli_stmt_get_result($stmt);

            // Check if student already has a pending request for this book
            $already_requested = "SELECT * FROM book_requests WHERE student_id = ? AND book_id = ? AND status = 'pending'";
            $stmt = mysqli_prepare($conn, $already_requested);
            mysqli_stmt_bind_param($stmt, "ii", $student_id, $book_id);
            mysqli_stmt_execute($stmt);
            $requested_check_result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($issued_check_result) > 0) {
                $error = "You already have this book borrowed!";
            } elseif (mysqli_num_rows($requested_check_result) > 0) {
                $error = "You already have a pending request for this book!";
            } else {
                // Submit request for admin approval
                $request_query = "INSERT INTO book_requests (student_id, book_id, status) VALUES (?, ?, 'pending')";
                $stmt = mysqli_prepare($conn, $request_query);
                mysqli_stmt_bind_param($stmt, "ii", $student_id, $book_id);

                if (mysqli_stmt_execute($stmt)) {
                    $success = "Book request submitted! Please wait for admin approval.";
                    $pending_count++;
                    $active_count = $issued_count + $pending_count;
                    $can_borrow_more = ($active_count < $max_books);
                } else {
                    $error = "Error submitting request. Please try again.";
                }
            }
        } else {
            $error = "This book is currently not available!";
        }
    }
}

// Get all available books with search and filter
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$category_filter = isset($_GET['category']) ? intval($_GET['category']) : 0;
$author_filter = isset($_GET['author']) ? intval($_GET['author']) : 0;

$books_query = "SELECT b.*, a.author_name as author_name, c.category_name as category_name 
                FROM books b 
                JOIN authors a ON b.author_id = a.id 
                JOIN categories c ON b.category_id = c.id 
                WHERE b.available_quantity > 0";

$params = [];
$types = '';

if ($search) {
    $books_query .= " AND (b.title LIKE ? OR a.author_name LIKE ? OR b.isbn LIKE ?)";
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $types .= 'sss';
}

if ($category_filter > 0) {
    $books_query .= " AND b.category_id = ?";
    $params[] = $category_filter;
    $types .= 'i';
}

if ($author_filter > 0) {
    $books_query .= " AND b.author_id = ?";
    $params[] = $author_filter;
    $types .= 'i';
}

$books_query .= " ORDER BY b.title ASC";

$books_stmt = mysqli_prepare($conn, $books_query);
if ($types) {
    mysqli_stmt_bind_param($books_stmt, $types, ...$params);
}
mysqli_stmt_execute($books_stmt);
$books_result = mysqli_stmt_get_result($books_stmt);

// Get categories for filter
$categories_result = mysqli_query($conn, "SELECT * FROM categories ORDER BY category_name");

// Get authors for filter
$authors_result = mysqli_query($conn, "SELECT * FROM authors ORDER BY author_name");

// Get this student's pending requests, to show status inline
$pending_book_ids = [];
$req_stmt = mysqli_prepare($conn, "SELECT book_id FROM book_requests WHERE student_id = ? AND status = 'pending'");
mysqli_stmt_bind_param($req_stmt, "i", $student_id);
mysqli_stmt_execute($req_stmt);
$req_result = mysqli_stmt_get_result($req_stmt);
while ($row = mysqli_fetch_assoc($req_result)) {
    $pending_book_ids[] = $row['book_id'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrow Books - Library System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .header {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .header h1 {
            color: #333;
            margin-bottom: 10px;
        }

        .student-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .info-badge {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            font-weight: 600;
        }

        .limit-warning {
            background: #fef3c7;
            color: #92400e;
            padding: 10px 20px;
            border-radius: 25px;
            font-weight: 600;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }

        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid #ef4444;
        }

        .filter-section {
            background: white;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
        }

        .filter-group label {
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }

        .filter-group input,
        .filter-group select {
            padding: 10px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 1em;
        }

        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: #667eea;
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
            text-decoration: none;
            display: inline-block;
        }

        .btn:hover {
            transform: scale(1.02);
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }

        .books-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .book-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .book-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        .book-header {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f3f4f6;
        }

        .book-title {
            font-size: 1.3em;
            color: #333;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .book-author {
            color: #6b7280;
            font-size: 1em;
            margin-bottom: 5px;
        }

        .book-category {
            display: inline-block;
            background: #e0e7ff;
            color: #4338ca;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 600;
        }

        .book-details {
            margin: 15px 0;
        }

        .book-detail-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #f3f4f6;
        }

        .book-detail-row:last-child {
            border-bottom: none;
        }

        .detail-label {
            color: #6b7280;
            font-weight: 500;
        }

        .detail-value {
            color: #111827;
            font-weight: 600;
        }

        .availability-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 600;
        }

        .available {
            background: #d1fae5;
            color: #065f46;
        }

        .limited {
            background: #fef3c7;
            color: #92400e;
        }

        .borrow-form {
            margin-top: 15px;
        }

        .btn-borrow {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1em;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .btn-borrow:hover {
            transform: scale(1.02);
        }

        .btn-borrow:disabled {
            background: #9ca3af;
            cursor: not-allowed;
            transform: none;
        }

        .btn-pending {
            width: 100%;
            padding: 12px;
            background: #fef3c7;
            color: #92400e;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1em;
            text-align: center;
        }

        .no-books {
            background: white;
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            color: #6b7280;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: white;
            text-decoration: none;
            font-weight: 600;
            padding: 10px 20px;
            background: rgba(255,255,255,0.2);
            border-radius: 8px;
            transition: background 0.3s;
        }

        .back-link:hover {
            background: rgba(255,255,255,0.3);
        }

        @media (max-width: 768px) {
            .books-grid {
                grid-template-columns: 1fr;
            }
            
            .student-info {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="student_dashboard.php" class="back-link">← Back to Dashboard</a>

        <div class="header">
            <h1>📚 Borrow Books</h1>
            <div class="student-info">
                <div>
                    <strong>Student:</strong> <?php echo htmlspecialchars($student['full_name']); ?> 
                    (<?php echo htmlspecialchars($student['student_id']); ?>)
                </div>
                <div class="info-badge">
                    Issued: <?php echo $issued_count; ?> · Pending: <?php echo $pending_count; ?> / <?php echo $max_books; ?>
                </div>
                <?php if (!$can_borrow_more): ?>
                    <div class="limit-warning">
                        ⚠️ Maximum limit reached!
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success">✓ <?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error">✕ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="filter-section">
            <form method="GET" action="">
                <div class="filter-grid">
                    <div class="filter-group">
                        <label>Search Books</label>
                        <input type="text" name="search" placeholder="Title, Author, ISBN..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="filter-group">
                        <label>Category</label>
                        <select name="category">
                            <option value="0">All Categories</option>
                            <?php while ($cat = mysqli_fetch_assoc($categories_result)): ?>
                                <option value="<?php echo $cat['id']; ?>" <?php echo ($category_filter == $cat['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['category_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Author</label>
                        <select name="author">
                            <option value="0">All Authors</option>
                            <?php while ($auth = mysqli_fetch_assoc($authors_result)): ?>
                                <option value="<?php echo $auth['id']; ?>" <?php echo ($author_filter == $auth['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($auth['author_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="filter-buttons">
                        <button type="submit" class="btn btn-primary">🔍 Filter</button>
                        <a href="borrow_book.php" class="btn btn-secondary">Clear</a>
                    </div>
                </div>
            </form>
        </div>

        <div class="books-grid">
            <?php if (mysqli_num_rows($books_result) > 0): ?>
                <?php while ($book = mysqli_fetch_assoc($books_result)): ?>
                    <?php $is_pending = in_array($book['id'], $pending_book_ids); ?>
                    <div class="book-card">
                        <div class="book-header">
                            <div class="book-title"><?php echo htmlspecialchars($book['title']); ?></div>
                            <div class="book-author">by <?php echo htmlspecialchars($book['author_name']); ?></div>
                            <span class="book-category"><?php echo htmlspecialchars($book['category_name']); ?></span>
                        </div>

                        <div class="book-details">
                            <div class="book-detail-row">
                                <span class="detail-label">ISBN:</span>
                                <span class="detail-value"><?php echo htmlspecialchars($book['isbn']); ?></span>
                            </div>
                            <div class="book-detail-row">
                                <span class="detail-label">Total Copies:</span>
                                <span class="detail-value"><?php echo $book['quantity']; ?></span>
                            </div>
                            <div class="book-detail-row">
                                <span class="detail-label">Available:</span>
                                <span class="detail-value">
                                    <span class="availability-badge <?php echo ($book['available_quantity'] > 3) ? 'available' : 'limited'; ?>">
                                        <?php echo $book['available_quantity']; ?> copies
                                    </span>
                                </span>
                            </div>
                        </div>

                        <?php if ($book['description']): ?>
                            <div style="margin: 15px 0; color: #6b7280; font-size: 0.9em; line-height: 1.5;">
                                <?php echo htmlspecialchars(substr($book['description'], 0, 150)); ?>
                                <?php echo (strlen($book['description']) > 150) ? '...' : ''; ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($is_pending): ?>
                            <div class="btn-pending">⏳ Request Pending Approval</div>
                        <?php else: ?>
                            <form method="POST" action="" class="borrow-form">
                                <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                                <button type="submit" name="borrow_book" class="btn-borrow" <?php echo (!$can_borrow_more) ? 'disabled' : ''; ?>>
                                    <?php echo ($can_borrow_more) ? '📖 Request to Borrow' : '⚠️ Limit Reached'; ?>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="no-books">
                    <h2>📚 No Books Found</h2>
                    <p>Try adjusting your search or filter criteria.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

<?php mysqli_close($conn); ?>