<?php
// return_book.php
require_once 'config.php';

if (!isStudent()) {
    header('Location: student_login.php');
    exit();
}

$student_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Handle return request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['request_return'])) {
    $issued_id = intval($_POST['issued_id']);

    // Confirm this issued_books row belongs to this student and is still out
    $check_stmt = mysqli_prepare($conn, "SELECT * FROM issued_books WHERE id = ? AND student_id = ? AND return_date IS NULL AND status = 'issued'");
    mysqli_stmt_bind_param($check_stmt, "ii", $issued_id, $student_id);
    mysqli_stmt_execute($check_stmt);
    $issued_row = mysqli_fetch_assoc(mysqli_stmt_get_result($check_stmt));

    if (!$issued_row) {
        $error = "That book isn't currently marked as issued to you.";
    } else {
        // Prevent duplicate pending return requests for the same issued book
        $dup_stmt = mysqli_prepare($conn, "SELECT id FROM book_requests WHERE issued_book_id = ? AND request_type = 'return' AND status = 'pending'");
        mysqli_stmt_bind_param($dup_stmt, "i", $issued_id);
        mysqli_stmt_execute($dup_stmt);
        $dup_result = mysqli_stmt_get_result($dup_stmt);

        if (mysqli_num_rows($dup_result) > 0) {
            $error = "You already have a pending return request for this book.";
        } else {
            $insert_stmt = mysqli_prepare($conn, "INSERT INTO book_requests (student_id, book_id, request_type, issued_book_id, status) VALUES (?, ?, 'return', ?, 'pending')");
            mysqli_stmt_bind_param($insert_stmt, "iii", $student_id, $issued_row['book_id'], $issued_id);

            if (mysqli_stmt_execute($insert_stmt)) {
                $success = "Return request submitted! Please wait for admin confirmation.";
            } else {
                $error = "Error submitting return request. Please try again.";
            }
        }
    }
}

// Get all books currently issued to this student (not yet returned)
$issued_stmt = mysqli_prepare($conn, "
    SELECT ib.id AS issued_id, ib.issue_date, ib.due_date, b.title, b.isbn
    FROM issued_books ib
    JOIN books b ON ib.book_id = b.id
    WHERE ib.student_id = ? AND ib.return_date IS NULL AND ib.status = 'issued'
    ORDER BY ib.due_date ASC
");
mysqli_stmt_bind_param($issued_stmt, "i", $student_id);
mysqli_stmt_execute($issued_stmt);
$issued_result = mysqli_stmt_get_result($issued_stmt);

// Get issued_ids that already have a pending return request
$pending_returns = [];
$pr_stmt = mysqli_prepare($conn, "SELECT issued_book_id FROM book_requests WHERE student_id = ? AND request_type = 'return' AND status = 'pending'");
mysqli_stmt_bind_param($pr_stmt, "i", $student_id);
mysqli_stmt_execute($pr_stmt);
$pr_result = mysqli_stmt_get_result($pr_stmt);
while ($row = mysqli_fetch_assoc($pr_result)) {
    $pending_returns[] = $row['issued_book_id'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Return Books</title>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background:linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height:100vh; padding:20px; }
    .container { max-width:900px; margin:0 auto; }
    .back-link { display:inline-block; margin-bottom:20px; color:white; text-decoration:none; font-weight:600; padding:10px 20px; background:rgba(255,255,255,0.2); border-radius:8px; }
    .back-link:hover { background:rgba(255,255,255,0.3); }
    .header { background:white; padding:25px; border-radius:15px; margin-bottom:20px; box-shadow:0 5px 15px rgba(0,0,0,0.1); }
    .header h1 { color:#333; }
    .alert { padding:15px 20px; border-radius:10px; margin-bottom:20px; font-weight:500; }
    .alert-success { background:#d1fae5; color:#065f46; border-left:4px solid #10b981; }
    .alert-error { background:#fee2e2; color:#991b1b; border-left:4px solid #ef4444; }
    .card { background:white; border-radius:15px; padding:20px; box-shadow:0 5px 15px rgba(0,0,0,0.1); margin-bottom:15px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; }
    .book-info h3 { color:#333; margin-bottom:5px; }
    .book-info p { color:#6b7280; font-size:0.9em; }
    .overdue { color:#dc2626; font-weight:700; }
    .btn { padding:10px 20px; border:none; border-radius:8px; font-weight:600; cursor:pointer; }
    .btn-return { background:linear-gradient(135deg, #10b981 0%, #059669 100%); color:white; }
    .btn-pending { background:#fef3c7; color:#92400e; padding:10px 20px; border-radius:8px; font-weight:600; }
    .no-books { background:white; padding:40px; border-radius:15px; text-align:center; color:#6b7280; }
</style>
</head>
<body>
<div class="container">
    <a href="student_dashboard.php" class="back-link">← Back to Dashboard</a>

    <div class="header">
        <h1>📗 Return Books</h1>
    </div>

    <?php if ($success): ?><div class="alert alert-success">✓ <?php echo htmlspecialchars($success); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error">✕ <?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <?php if (mysqli_num_rows($issued_result) === 0): ?>
        <div class="no-books">
            <h2>📚 No Books Currently Issued</h2>
            <p>You don't have any books out to return right now.</p>
        </div>
    <?php else: ?>
        <?php while ($book = mysqli_fetch_assoc($issued_result)): ?>
            <?php
                $is_overdue = strtotime($book['due_date']) < strtotime(date('Y-m-d'));
                $has_pending = in_array($book['issued_id'], $pending_returns);
            ?>
            <div class="card">
                <div class="book-info">
                    <h3><?php echo htmlspecialchars($book['title']); ?></h3>
                    <p>ISBN: <?php echo htmlspecialchars($book['isbn']); ?></p>
                    <p>Issued: <?php echo date('M d, Y', strtotime($book['issue_date'])); ?> —
                        Due: <span class="<?php echo $is_overdue ? 'overdue' : ''; ?>"><?php echo date('M d, Y', strtotime($book['due_date'])); ?><?php echo $is_overdue ? ' (Overdue)' : ''; ?></span>
                    </p>
                </div>
                <?php if ($has_pending): ?>
                    <div class="btn-pending">⏳ Return Pending Approval</div>
                <?php else: ?>
                    <form method="POST">
                        <input type="hidden" name="issued_id" value="<?php echo $book['issued_id']; ?>">
                        <button type="submit" name="request_return" class="btn btn-return">📗 Request Return</button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
    <?php endif; ?>
</div>
</body>
</html>
<?php mysqli_close($conn); ?>
